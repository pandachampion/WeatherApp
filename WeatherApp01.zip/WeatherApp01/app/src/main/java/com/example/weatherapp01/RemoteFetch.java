package com.example.weatherapp01;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class RemoteFetch {
    private static final String OPEN_WEATHER_MAP_API =
            "https://api.weather.gov/alerts/active?area=%s";

    public static org.json.JSONObject getJSON(int zipCode){
       System.out.println("I'm the zipcode: " + zipCode);
        try {
            java.net.URL url = new java.net.URL(String.format(OPEN_WEATHER_MAP_API, zipCode));
            java.net.HttpURLConnection connection =
                    (java.net.HttpURLConnection)url.openConnection();

            //connection.addRequestProperty("x-api-key",
                    //context.getString(R.string.open_we));

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(connection.getInputStream()));

            StringBuffer json = new StringBuffer(1024);
            String tmp="";
            while((tmp=reader.readLine())!=null)
                json.append(tmp).append("\n");
            reader.close();

            JSONObject data = new JSONObject(json.toString());

            // This value will be 404 if the request was not
            // successful
            if(data.getInt("cod") != 200){
                return null;
            }
            System.out.println(data);
            return data;
        }catch(Exception e){
            return null;
        }
    }
}
