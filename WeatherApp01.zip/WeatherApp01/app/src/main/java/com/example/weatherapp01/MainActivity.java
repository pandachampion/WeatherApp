package com.example.weatherapp01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {




    android.widget.EditText zipCodeInput;

    Button submitButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        zipCodeInput = findViewById(R.id.zipCodeInput);
        submitButton = findViewById(R.id.submitButton);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int zipCode = Integer.valueOf(zipCodeInput.getText().toString());
                System.out.println(zipCode);
                RemoteFetch.getJSON(zipCode);
                showToast(String.valueOf(zipCode));
            }
        });
    }

    private void showToast(String text){
        android.widget.Toast.makeText(MainActivity.this, text, android.widget.Toast.LENGTH_SHORT).show();
    }

}