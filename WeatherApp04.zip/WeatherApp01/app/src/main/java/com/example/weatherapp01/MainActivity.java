package com.example.weatherapp01;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationResult;

import android.annotation.SuppressLint;
import android.location.Location;
import android.os.Looper;

import com.google.android.gms.tasks.OnSuccessListener;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.Manifest;
import android.content.pm.PackageManager;
import java.util.HashMap;


import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    android.widget.EditText zipCodeInput;
    Button submitButton;
    ExecutorService executorService = Executors.newFixedThreadPool(4);

    private FusedLocationProviderClient fusedLocationClient;
    private LocationRequest locationRequest;
    private LocationCallback locationCallback;
    private LocationResult locationResult;
    double latitude;
    double longitude;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // First get permissions to access location.
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        if (getApplicationContext().checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED) {
            // You can use the API that requires the permission.
            Toast.makeText(MainActivity.this, "Permission granted", Toast.LENGTH_SHORT).show();

            // Permission already granted. Get locationUpdates.
            startLocationUpdates();
        } else {
            // You can directly ask for the permission.
            // The registered ActivityResultCallback gets the result of this request.
            requestPermissions(new String[]{
                    Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        }
    }

    // Start fetching location updates
    private void startLocationUpdates() {
        // Create the location request to start receiving updates.
        locationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY)
                .setInterval(10 * 1000)
                .setFastestInterval(1 * 1000);

        try {
            fusedLocationClient.requestLocationUpdates(locationRequest,
                    new LocationCallback() {
                        @Override
                        public void onLocationResult(LocationResult locationResult) {
                            onLocationChanged(locationResult.getLastLocation());
                        }
                    },
                    Looper.getMainLooper());
        } catch (SecurityException e) {
            System.out.println(e);
        }
    }

    // When a change of location is detected, fetch the alerts.
    public void onLocationChanged(final Location location) {
        // New location has now been determined
        String msg = "Updated Location: " +
                Double.toString(location.getLatitude()) + "," +
                Double.toString(location.getLongitude());
        System.out.println(msg);
         executorService.execute(new Runnable() {
                @Override
                public void run() {
                    // Location to hard-code to check for an alert - latitude = 35.2828; longitude = -120.6596;
                    HashMap headline = RemoteFetch.getAlert(location.getLatitude(), location.getLongitude());
                    TextView headlineText = (TextView) findViewById(R.id.headlineText);
                    if (headline.isEmpty()) {
                        headlineText.setText("Found no Active Alerts for your area!");
                    } else {
                        headlineText.setText(headline + "");
                    }
                }
            });
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(MainActivity.this, "Permission granted. Fetching alerts",
                        Toast.LENGTH_SHORT).show();
                try {
                    if (ActivityCompat.checkSelfPermission(
                            this, Manifest.permission.ACCESS_FINE_LOCATION) !=
                            PackageManager.PERMISSION_GRANTED
                            && ActivityCompat.checkSelfPermission(this,
                            Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        // TODO: Consider calling
                        //    ActivityCompat#requestPermissions
                        // here to request the missing permissions, and then overriding
                        //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                        //                                          int[] grantResults)
                        // to handle the case where the user grants the permission. See the documentation
                        // for ActivityCompat#requestPermissions for more details.
                        return;
                    }
                    fusedLocationClient.getLastLocation()
                            .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                                @Override
                                public void onSuccess(final Location location) {
                                    if (location != null) {
                                      System.out.println("User location: " + location);
                                      onLocationChanged(location);
                                    } else {
                                      System.out.println("No location! Please make sure location is enabled on your phone. Please try again.");
                                    }
                                }
                            });
                } catch (Exception e) {
                    System.out.println(e);
                }
            } else {
                // User denied the request for app to access their location
                Toast.makeText(MainActivity.this, "Permission denied",
                        Toast.LENGTH_SHORT).show();

                // Display a box for user to enter the state. Fetch all active alerts for the state
                // display it.

                //zipCodeInput = findViewById(R.id.zipCodeInput);
                //submitButton = findViewById(R.id.submitButton);
                //submitButton.setOnClickListener(new View.OnClickListener() {
                //@SuppressLint("NewApi")
                //@Override
                //public void onClick(View v) {
                // User clicked submit. Now check if user gave permission to access their location

                //EditText zipCodeInput = (EditText) findViewById(R.id.zipCodeInput);
                //int zipCode = Integer.valueOf(zipCodeInput.getText().toString());
                //zipCodeInput.setText(zipCode + "");
                //System.out.println(zipCode);
                //showToast(String.valueOf(zipCode));
                //}


                //System.out.println("User didn't give access to location. Nothing to do");
                //});
            }

        }
    }

    private void showToast(String text) {
        android.widget.Toast.makeText(MainActivity.this, text, android.widget.Toast.LENGTH_SHORT).show();
    }
}