package com.example.weatherapp01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class NoLocationActivity extends AppCompatActivity {

        @Override
        protected void onCreate(Bundle savedInstanceState){
            super.onCreate(savedInstanceState);
            setContentView(R.layout.no_location);
        }
}
