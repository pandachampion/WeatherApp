package com.example.weatherapp01;

import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import android.location.Location;

import com.google.android.gms.tasks.OnSuccessListener;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.manifest.permission;


import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    android.widget.EditText zipCodeInput;
    Button submitButton;
    ExecutorService executorService = Executors.newFixedThreadPool(4);

    private FusedLocationProviderClient fusedLocationClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        zipCodeInput = findViewById(R.id.zipCodeInput);
        submitButton = findViewById(R.id.submitButton);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // User clicked submit. Now get the user's location.
                if (ContextCompat.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION ==
                        PackageManager.PERMISSION_GRANTED)) {
                    // You can use the API that requires the permission.
                    Toast.makeText(MainActivity.this, "Permission granted", Toast.LENGTH_SHORT).show();
                } else {
                    // You can directly ask for the permission.
                    // The registered ActivityResultCallback gets the result of this request.
                    requestPermissionLauncher.launch(
                            Manifest.permission.ACCESS_COARSE_LOCATION);
                }

                fusedLocationClient.getLastLocation()
                        .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                            @Override
                            public void onSuccess(Location location) {
                                if (location != null) {
                                    System.out.println("User location: " + location);
                                    executorService.execute(new Runnable() {
                                        @Override
                                        public void run() {
                                            Object headline = RemoteFetch.getHeadline(1);
                                            TextView headlineText = (TextView) findViewById(R.id.headlineText);
                                            headlineText.setText(headline + "");
                                        }
                                    });
                                } else {
                                    System.out.println("No location!");
                                }
                            }
                        });

                //EditText zipCodeInput = (EditText) findViewById(R.id.zipCodeInput);
                //int zipCode = Integer.valueOf(zipCodeInput.getText().toString());
                //zipCodeInput.setText(zipCode + "");
                //System.out.println(zipCode);
                showToast(String.valueOf(zipCode));
            }


            //System.out.println("User didn't give access to location. Nothing to do");
        });
    }
    @Override
    public void onRequstPermissionResult(int requestCode, String[] permissions, int grantResults){
        super. onRequstPermissionResult(requestCode, permissions, grantResults);
        if (requestCode == 1){
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED)   {
                Toast.makeText(MainActivity.this, "Permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "Permission denied", Toast.LENGTH_SHORT).show();
            }

        }
    }

    private void showToast(String text){
        android.widget.Toast.makeText(MainActivity.this, text, android.widget.Toast.LENGTH_SHORT).show();
    }

    private void fetchLocation() {


    }

}