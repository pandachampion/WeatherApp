package com.example.weatherapp01;

import android.widget.TextView;

import org.json.JSONObject;
import org.json.JSONArray;
import org.json.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class RemoteFetch {
    private static final String URL =
            "https://api.weather.gov/alerts/active?area=%s";

    public static Object getHeadline(int zipCode){
       System.out.println("I'm the zipcode: " + "CA");
        try {
            java.net.URL url = new java.net.URL(String.format(URL, "CA"));
            System.out.println("I'm the URL: " + url);
            java.net.HttpURLConnection connection =
                    (java.net.HttpURLConnection)url.openConnection();
            connection.setRequestProperty("User-Agent", "Test");

            //connection.addRequestProperty("x-api-key",
                    //context.getString(R.string.open_we));

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(connection.getInputStream()));

            StringBuffer json = new StringBuffer(1024);
            String tmp= "";
            while ((tmp = reader.readLine()) != null)
                json.append(tmp).append("\n");
            reader.close();


            JSONObject data = new JSONObject(json.toString());
            JSONArray features = (JSONArray)data.get("features");
            JSONObject obj = (JSONObject)features.getJSONObject(0);
            JSONObject properties = (JSONObject)obj.get("properties");
            Object headline = properties.get("headline");
            System.out.println(headline);



            return headline;
        } catch (Exception e){
            System.out.println("Exception " + e.toString());
            return null;
        }
    }
}
